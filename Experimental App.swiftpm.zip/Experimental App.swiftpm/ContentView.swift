import SwiftUI
import AuthenticationServices

struct ContentView: View {
    var body: some View {
        VStack {
            HStack {
                Image(systemName: "checklist")
                    .imageScale(.large)
                    .foregroundColor(.accentColor)
                
                Image(systemName: "plus")
                    .imageScale(.small)
                    .foregroundColor(.black)
                    
                
                Image(systemName: "calendar")
                    .imageScale(.large)
                    .foregroundColor(.accentColor)
                    
            }
            Text("Welcome to a modern planning app for students")
                .padding()
            
            HStack {
                Button("Sign In", action: signIn)
                Button("Register", action: register)
            }
            .buttonStyle(.borderedProminent)
        }
    }
    
    func signIn(){
        print("Signed in")
    }
    
    func register() {
        print("Registered")
    }
}
