
Lucky Charms - v2 2022-03-20 6:39pm
==============================

This dataset was exported via roboflow.ai on March 21, 2022 at 6:30 PM GMT

It includes 52 images.
Marshmallows are annotated in COCO format.

The following pre-processing was applied to each image:

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Randomly crop between 0 and 25 percent of the image
* Random Gaussian blur of between 0 and 10 pixels


